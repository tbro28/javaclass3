package edu.uw;

/**
 * Place holder class to aid in importing template maven project into Eclipse, servers no other purpose.
 *
 * @author Russ Moul
 */
public final class DeleteMe {
}

