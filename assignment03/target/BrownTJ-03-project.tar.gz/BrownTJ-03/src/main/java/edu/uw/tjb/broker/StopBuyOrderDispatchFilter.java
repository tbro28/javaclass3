package edu.uw.tjb.broker;

/**
 * Use of the class is discouraged, the BiPredicate<Integer, StopBuyOrder> interface
 * and a lambda expression, is sufficient.
 */
public class StopBuyOrderDispatchFilter {
}
