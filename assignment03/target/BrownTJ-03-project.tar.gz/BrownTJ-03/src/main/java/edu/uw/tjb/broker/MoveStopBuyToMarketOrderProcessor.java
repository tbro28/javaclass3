package edu.uw.tjb.broker;

/**
 * Use of the class is discouraged, the Consumer<StopBuyOrder> interface and a lambda expression,
 * is sufficient.
 */
public class MoveStopBuyToMarketOrderProcessor {


    public void accept (edu.uw.ext.framework.order.StopBuyOrder order) {

    }


}
