package edu.uw.tjb.broker;

import edu.uw.ext.framework.exchange.StockExchange;
import edu.uw.tjb.account.SimpleAccountManager;
import edu.uw.tjb.dao.FileAccountDao;

public class TestSolution {



    public static void main(String args[]) {

        StockExchange stockExchange = null;
        FileAccountDao fileAccountDao = null;

      //  ExecutorBroker simpleBroker = new ExecutorBroker("TimCo", stockExchange, fileAccountDao);

        //SimpleAccountManager simpleAccountManager = new SimpleAccountManager();


        System.out.println("You");


    }

}
