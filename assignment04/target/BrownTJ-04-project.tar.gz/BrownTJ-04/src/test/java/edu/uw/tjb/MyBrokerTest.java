package edu.uw.tjb;

class MyBrokerTest extends test.BrokerTest {}
